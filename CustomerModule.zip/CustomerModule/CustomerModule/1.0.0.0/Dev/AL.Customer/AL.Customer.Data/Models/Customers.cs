﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace AL.Customer.Data.Models
{
    public class Customers
    {
        public Customers()
        {
            Orders = new HashSet<Orders>();
        }

        [Key]
        public int Identifier { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public bool? IsActive { get; set; }
        public bool IsLocked { get; set; }
        public bool? IsFirstTime { get; set; }
        public DateTime TimeStamp { get; set; }

        public virtual ICollection<Orders> Orders { get; set; }
    }
}
