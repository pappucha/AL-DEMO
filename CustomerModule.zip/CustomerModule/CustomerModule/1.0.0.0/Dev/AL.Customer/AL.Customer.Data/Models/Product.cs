﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace AL.Customer.Data.Models
{
    public class Product
    {
        public Product()
        {
            Orders = new HashSet<Orders>();
        }

        [Key]
        public int Identifier { get; set; }
        public string ProductName { get; set; }
        public decimal Price { get; set; }
        public bool? Issold { get; set; }
        public DateTime TimeStamp { get; set; }

        public virtual ICollection<Orders> Orders { get; set; }
    }
}
