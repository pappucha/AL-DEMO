﻿using System;
using System.Collections.Generic;
using System.Text;
using AL.Customer.Data.Models;
using System.Linq;

namespace AL.Customer.Data.Services
{
    public class OrderRepository : BaseRepository<Models.Orders>, Interface.IOrderRepository
    {
        public OrderRepository(DataAccess.CustomerContext context) : base(context)
        {

        }
        public List<Orders> GetOrderDetailsByCustomerID(int customerID)
        {
            return db.Orders.Where(a => a.CustomerId == customerID).ToList();
        }

        public bool AddOrderForCustomer(Orders orders)
        {
            db.Orders.Add(orders);
            db.SaveChanges();
            return true;
        }

        public bool IsOrderSold(int customerID, int orderID)
        {
            return true;
        }
    }
}
