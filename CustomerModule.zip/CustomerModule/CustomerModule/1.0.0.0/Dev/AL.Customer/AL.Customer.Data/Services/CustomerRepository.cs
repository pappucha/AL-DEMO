﻿using AL.Customer.Data.DataAccess;
using AL.Customer.Data.Interface;
using AL.Customer.Data.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Linq;

namespace AL.Customer.Data.Services
{
    public class CustomerRepository : BaseRepository<Customers>, ICustomerRepository
    {
        public CustomerRepository(CustomerContext context) : base(context)
        {

        }

        public Customers GetUserDetailsByIdentifier(int ID)
        {
            return db.Customer.Where(a => a.Identifier == ID).FirstOrDefault();
        }

        public List<Customers> CustomerNoOrder()
        {
            List<Customers> getCustomerNoOrders = (from cust in db.Customer where !(from o in db.Orders select o.CustomerId).Contains(cust.Identifier) select cust).ToList();
            return getCustomerNoOrders;
        }

        public bool SaveCustomer(Customers customerMode)
        {
            db.Customer.Add(customerMode);
            db.SaveChanges();
            return true;
        }


    }
}
