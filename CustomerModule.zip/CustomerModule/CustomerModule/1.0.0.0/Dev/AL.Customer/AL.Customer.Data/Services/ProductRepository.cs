﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace AL.Customer.Data.Services
{
    public class ProductRepository : BaseRepository<Models.Product>, Interface.IProductRepository
    {
        public ProductRepository(DataAccess.CustomerContext context) : base(context)
        {

        }

        public Models.Product GetProductDetailByOrderID(int orderID)
        {
            return db.Product.Where(a => a.Identifier == orderID).FirstOrDefault();
        }

        public bool IsProductSold(int orderID)
        {
            return db.Product.Any(a => a.Identifier == orderID && a.Issold == true);
        }
    }
}
