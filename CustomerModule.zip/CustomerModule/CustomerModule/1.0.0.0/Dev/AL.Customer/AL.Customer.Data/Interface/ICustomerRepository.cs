﻿using AL.Customer.Data.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace AL.Customer.Data.Interface
{
    public interface ICustomerRepository : IBaseRepository<Customers>
    {
        Customers GetUserDetailsByIdentifier(int ID);

        List<Customers> CustomerNoOrder();

        bool SaveCustomer(Customers customerMode);
    }
}
