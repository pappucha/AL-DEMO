﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AL.Customer.Data.Interface
{
    public interface IOrderRepository : IBaseRepository<Models.Orders>
    {
        List<Models.Orders> GetOrderDetailsByCustomerID(int customerID);

        bool AddOrderForCustomer(Models.Orders orders);

        bool IsOrderSold(int customerID, int orderID);
    }
}
