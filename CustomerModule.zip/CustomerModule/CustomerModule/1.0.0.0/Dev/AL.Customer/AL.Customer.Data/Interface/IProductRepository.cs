﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AL.Customer.Data.Interface
{
    public interface IProductRepository : IBaseRepository<Models.Product>
    {
        Models.Product GetProductDetailByOrderID(int orderID);

        bool IsProductSold(int OrderID);
    }
}
