﻿using System;
using System.Collections.Generic;
using System.Text;


namespace AL.Customer.Domain.Mapper
{
    public static class CustomerMapper
    {
        public static List<Effigy.Models.CustomerModel> MapCustomerWithOutOrder(List<Data.Models.Customers> customer)
        {
            List<Effigy.Models.CustomerModel> customerModel = new List<Effigy.Models.CustomerModel>();
            foreach (var item in customer)
            {
                Effigy.Models.CustomerModel model = new Effigy.Models.CustomerModel();
                model.Email = item.Email;
                model.Name = item.Name;
                model.CustomerID = item.Identifier;
                customerModel.Add(model);
            }

            return customerModel;
        }

        public static Data.Models.Customers AddCustomerMapper(Effigy.Models.CustomerModel customerModel)
        {
            Data.Models.Customers customers = new Data.Models.Customers();
            if (customerModel != null)
            {
                customers.Name = customerModel.Name;
                customers.Email = customerModel.Email;
                customers.IsActive = true;
                customers.IsLocked = false;
                customers.IsFirstTime = false;
                customers.TimeStamp = DateTime.Now;

            }
            return customers;
        }

        public static Data.Models.Orders AddProdctOrderMapper(Effigy.Models.CustomerModel customerModel)
        {
            Data.Models.Orders orders = new Data.Models.Orders();
            if (customerModel != null)
            {
                if (customerModel.OrderDetails != null && customerModel.OrderDetails.Count > 0)
                {
                    foreach (Effigy.Models.OrderModel item in customerModel.OrderDetails)
                    {
                        orders.CustomerId = item.CustomerID;
                        orders.OrderId = item.OrderID;
                        orders.OrderDate = DateTime.Now;
                    }
                }
            }
            
            return orders;
        }

        public static Effigy.Models.CustomerModel MapCustomerOrderDetails(Data.Models.Customers customer, List<Data.Models.Product> products)
        {
            Effigy.Models.CustomerModel customerModel = new Effigy.Models.CustomerModel();

            if (customer != null)
            {
                customerModel.CustomerID = customer.Identifier;
                customerModel.Email = customer.Email;
                customerModel.Name = customer.Name;
            }

           if (products != null && products.Count > 0)
            {
                customerModel.ProductModels = new List<Effigy.Models.ProductModel>();
                foreach (Data.Models.Product item in products)
                {
                    Effigy.Models.ProductModel productModel = new Effigy.Models.ProductModel();
                    productModel.ProductName = item.ProductName;
                    productModel.Price = item.Price;
                    productModel.Issold = item.Issold;
                    customerModel.ProductModels.Add(productModel);
                }

            }

            return customerModel;
        }

    }
}
