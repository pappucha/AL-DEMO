﻿using AL.Customer.Data.Interface;
using AL.Customer.Data.Models;
using AL.Customer.Domain.Interface;
using AL.Customer.Effigy.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Linq;

namespace AL.Customer.Domain.Service
{
    public class CustomerService : ICustomerService
    {
        /// <summary>
        /// Defines the customer Repository.
        /// </summary>
        private readonly ICustomerRepository customerRepository;

        /// <summary>
        /// Defines the customer Repository.
        /// </summary>
        private readonly IOrderRepository orderRepository;

        /// <summary>
        /// Defines the customer Repository.
        /// </summary>
        private readonly IProductRepository productRepository;

        /// <summary>
        /// Initializes a new instance of the <see cref="TieupService"/> class.
        /// </summary>
        /// <param name="_customerRepository">customer Repository.</param>
        public CustomerService(ICustomerRepository _customerRepository, IOrderRepository _orderRepository, IProductRepository _productRepository)
        {
            this.customerRepository = _customerRepository;
            this.orderRepository = _orderRepository;
            this.productRepository = _productRepository;
        }

        public Customers GetUserDetailsByIdentifier(int ID)
        {
            return this.customerRepository.GetUserDetailsByIdentifier(ID);
        }

        public List<CustomerModel> CustomerNoOrder()
        {
            List<Customers> customer = this.customerRepository.CustomerNoOrder();
            return Mapper.CustomerMapper.MapCustomerWithOutOrder(customer);
        }

        public Task<CustomerModel> CustomeOrderDetailsByID(int customerID)
        {
            CustomerModel model = new CustomerModel();
            List<Product> products = new List<Product>();
            Customers customer = this.customerRepository.GetUserDetailsByIdentifier(customerID);
            List<Orders> orders = this.orderRepository.GetOrderDetailsByCustomerID(customerID);
            foreach (Orders item in orders)
            {
                Product productDetails = this.productRepository.GetProductDetailByOrderID(item.OrderId);
                products.Add(productDetails);
            }
            
            CustomerModel customerModel = Mapper.CustomerMapper.MapCustomerOrderDetails(customer, products);
            return Task.FromResult(customerModel);
        }

        public Task<CustomerModel> SaveCustomer(CustomerModel customerModel)
        {
            Customers customers = null;
            if (customerModel != null)
            {
                customers = Mapper.CustomerMapper.AddCustomerMapper(customerModel);
                bool saveCustomer = this.customerRepository.SaveCustomer(customers);
            }
            
            return Task.FromResult(customerModel);
        }

        public Task<CustomerModel> AddOrderForCustomer(CustomerModel customerModel)
        {
            Orders orders = null;
            if (customerModel != null)
            {
                if (customerModel.OrderDetails != null && customerModel.OrderDetails.Count > 0)
                {
                    foreach (OrderModel item in customerModel.OrderDetails)
                    {
                        bool validateOrderModel = this.productRepository.IsProductSold(item.OrderID);
                        if (validateOrderModel == true)
                        {
                            var rowstoBeDeleted = customerModel.OrderDetails.SingleOrDefault(r => r.OrderID == item.OrderID && r.CustomerID == item.CustomerID);
                            if (rowstoBeDeleted != null)
                            {
                                customerModel.OrderDetails.Remove(rowstoBeDeleted);
                            }
                            
                        }
                        ///If it does inform user that you have removed this item and added rest 
                    }
                }
                orders = Mapper.CustomerMapper.AddProdctOrderMapper(customerModel);
                bool saveOrderForCustomer = this.orderRepository.AddOrderForCustomer(orders);
            }

            return Task.FromResult(customerModel);
        }
    }
}
