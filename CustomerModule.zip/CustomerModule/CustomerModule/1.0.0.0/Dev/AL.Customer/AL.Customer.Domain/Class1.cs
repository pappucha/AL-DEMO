﻿using System;

namespace AL.Customer.Domain
{
    public class Class1
    {
    }
}
