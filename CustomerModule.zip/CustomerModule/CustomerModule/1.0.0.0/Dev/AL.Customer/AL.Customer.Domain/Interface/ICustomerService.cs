﻿using AL.Customer.Data.Models;
using AL.Customer.Effigy.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace AL.Customer.Domain.Interface
{
    public interface ICustomerService
    {
        Customers GetUserDetailsByIdentifier(int ID);

        List<CustomerModel> CustomerNoOrder();

        /// <summary>
        /// Get customer details By ID.
        /// </summary>
        /// <param name="customerID">Customer ID.</param>
        /// <returns>Get Customer Details.</returns>
        Task<CustomerModel> CustomeOrderDetailsByID(int customerID);

        Task<CustomerModel> SaveCustomer(CustomerModel customerModel);

        Task<CustomerModel> AddOrderForCustomer(CustomerModel customerModel);
    }
}
