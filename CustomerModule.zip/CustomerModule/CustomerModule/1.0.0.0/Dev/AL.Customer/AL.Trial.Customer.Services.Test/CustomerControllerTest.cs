﻿namespace AL.Trial.Customer.Services.Test
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    using System.Threading.Tasks;
    using AL.Customer.Domain.Interface;
    using AL.Customer.Effigy.Models;
    using AL.Customer.Services.Rest.Controllers;
    using Microsoft.AspNetCore.Mvc;
    ////using Microsoft.AspNetCore.Mvc;
    using Moq;
    using Xunit;

    /// <summary>
    /// Customer Controller test.
    /// </summary>
    public class CustomerControllerTest
    {
        /// <summary>
        /// Defines Customer Service.
        /// </summary>
        private readonly Mock<ICustomerService> customerService;

        /// <summary>
        /// Initializes a new instance of the <see cref="CustomerControllerTest"/> class.
        /// </summary>
        public CustomerControllerTest()
        {
            this.customerService = new Mock<ICustomerService>();
        }

        /// <summary>
        /// Get all Customer No order Success  test.
        /// </summary>
        /// <returns>Customer No order Success .</returns>
        [Fact]
        public async Task CustomerNoOrderSuccess()
        {
            //// Arrange
            var fakeCustomerModel = new List<CustomerModel>();
            fakeCustomerModel.Add(new CustomerModel() { CustomerID = 1, Name = "Test-1", Email = "Test1@Mail.com" });
            fakeCustomerModel.Add(new CustomerModel() { CustomerID = 2, Name = "Test-2", Email = "Test2@Mail.com" });
            fakeCustomerModel.Add(new CustomerModel() { CustomerID = 3, Name = "Test-3", Email = "Test3@Mail.com" });
            var expectedCount = 3;
            this.customerService.Setup(x => x.CustomerNoOrder()).Returns(fakeCustomerModel);
            var customerTypeController = new CustomerController(this.customerService.Object);
            //// Act
            var actionResult = await customerTypeController.CustomerNoOrder().ConfigureAwait(false) as OkObjectResult;
            Assert.NotNull(actionResult);
            Assert.NotNull(actionResult.Value);
            var okResult = Assert.IsType<OkObjectResult>(actionResult);
            var rankTypesDetails = Assert.IsAssignableFrom<List<CustomerModel>>(okResult.Value);
            Assert.Equal(expectedCount, rankTypesDetails.Count);
            this.customerService.VerifyAll();
            this.customerService.Verify(x => x.CustomerNoOrder(), Times.Once);
        }

        /// <summary>
        /// Get all Rank type method returns null.
        /// </summary>
        /// <returns>Returns null.</returns>
        [Fact]
        public async Task CustomerNoOrderWithReturnNull()
        {
            //// Arrange
            var fakeCustomerModel = new List<CustomerModel>();

            fakeCustomerModel = null;

            this.customerService.Setup(x => x.CustomerNoOrder()).Returns(fakeCustomerModel);
            var customerTypeController = new CustomerController(this.customerService.Object);

            //// Act
            var actionResult = await customerTypeController.CustomerNoOrder().ConfigureAwait(false) as NotFoundResult;

            // Assert
            Assert.IsType<NotFoundResult>(actionResult);
            this.customerService.VerifyAll();
            this.customerService.Verify(x => x.CustomerNoOrder(), Times.Once);
        }

        /// <summary>
        /// Create Customer Response.
        /// </summary>
        /// <returns>Create Customer Success.</returns>
        [Fact]
        public async Task CreateCustomerSuccess()
        {
            CustomerModel customerDetails = new CustomerModel()
            {
            };

            this.customerService.Setup(x => x.SaveCustomer(It.IsAny<CustomerModel>())).Returns(Task.FromResult(customerDetails));
            var customerController = new CustomerController(this.customerService.Object);

            var actionResult = customerController.SaveCustomer(customerDetails).Result;

            Assert.NotNull(actionResult);
            Assert.IsType<OkObjectResult>(actionResult);

            this.customerService.VerifyAll();
            this.customerService.Verify(x => x.SaveCustomer(It.IsAny<CustomerModel>()), Times.AtLeastOnce);
        }

        /// <summary>
        /// CreateCustomer Null.
        /// </summary>
        /// <returns>Create Customer Null Casses.</returns>
        [Fact]
        public async Task CreateCustomerModelNull()
        {
            CustomerModel customerDetails = null;

            this.customerService.Setup(x => x.SaveCustomer(It.IsAny<CustomerModel>())).Returns(Task.FromResult(customerDetails));
            var customerController = new CustomerController(this.customerService.Object);

            var actionResult = customerController.SaveCustomer(customerDetails).Result;

            Assert.NotNull(actionResult);
            Assert.IsType<NotFoundResult>(actionResult);

            this.customerService.Verify(x => x.SaveCustomer(It.IsAny<CustomerModel>()), Times.Never);
        }

        /// <summary>
        /// Add Order for Customer.
        /// </summary>
        /// <returns>Add Order for Customer.</returns>
        [Fact]
        public async Task AddOrderForCustomerSuccess()
        {
            CustomerModel customerDetails = new CustomerModel();
            customerDetails.Email = "Test1@mail.com";
            customerDetails.CustomerID = 1;
            customerDetails.Name = "Test1";
            customerDetails.OrderDetails = new List<OrderModel>();
            OrderModel orderModel = new OrderModel();
            orderModel.CustomerID = 1;
            orderModel.IsAvailable = true;
            orderModel.OrderID = 1;
            orderModel.Price = 12;
            orderModel.ProductName = "Shampoo";
            customerDetails.OrderDetails.Add(orderModel);

            this.customerService.Setup(x => x.AddOrderForCustomer(It.IsAny<CustomerModel>())).Returns(Task.FromResult(customerDetails));
            var customerController = new CustomerController(this.customerService.Object);

            var actionResult = customerController.AddOrderForCustomer(customerDetails).Result;

            Assert.NotNull(actionResult);
            Assert.IsType<OkObjectResult>(actionResult);

            this.customerService.VerifyAll();
            this.customerService.Verify(x => x.AddOrderForCustomer(It.IsAny<CustomerModel>()), Times.AtLeastOnce);
        }

        /// <summary>
        /// Add Order Customer for Null Null.
        /// </summary>
        /// <returns>Add Order Customer Null.</returns>
        [Fact]
        public async Task AddOrderForCustomerNull()
        {
            CustomerModel customerDetails = null;

            this.customerService.Setup(x => x.AddOrderForCustomer(It.IsAny<CustomerModel>())).Returns(Task.FromResult(customerDetails));
            var customerController = new CustomerController(this.customerService.Object);

            var actionResult = customerController.AddOrderForCustomer(customerDetails).Result;

            Assert.NotNull(actionResult);
            Assert.IsType<NotFoundResult>(actionResult);

            this.customerService.Verify(x => x.AddOrderForCustomer(It.IsAny<CustomerModel>()), Times.Never);
        }
    }
}
