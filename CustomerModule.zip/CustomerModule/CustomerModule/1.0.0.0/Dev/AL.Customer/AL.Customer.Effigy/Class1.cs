﻿using System;

namespace AL.Customer.Effigy
{
    public class Class1
    {
    }
}
