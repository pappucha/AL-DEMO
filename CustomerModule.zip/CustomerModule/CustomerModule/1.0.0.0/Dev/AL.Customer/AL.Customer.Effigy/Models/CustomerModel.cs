﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AL.Customer.Effigy.Models
{
    public class CustomerModel
    {
        public CustomerModel()
        {
            this.OrderDetails = new List<OrderModel>();
            this.ProductModels = new List<ProductModel>();
        }
        public int CustomerID { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public List<OrderModel> OrderDetails { get; set; }
        public List<ProductModel> ProductModels { get; set; }
    }
}
