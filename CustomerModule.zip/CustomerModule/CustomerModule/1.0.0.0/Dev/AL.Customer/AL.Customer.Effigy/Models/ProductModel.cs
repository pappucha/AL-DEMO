﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AL.Customer.Effigy.Models
{
    public class ProductModel
    {
        public int ProductID { get; set; }
        public string ProductName { get; set; }
        public decimal Price { get; set; }
        public bool? Issold { get; set; }
    }
}
