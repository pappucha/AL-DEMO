﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AL.Customer.Effigy.Models
{
    public class OrderModel
    {
        public int OrderID { get; set; }
        public int CustomerID { get; set; }
        public string ProductName { get; set; }
        public decimal Price { get; set; }
        public bool IsAvailable { get; set; }
    }
}
