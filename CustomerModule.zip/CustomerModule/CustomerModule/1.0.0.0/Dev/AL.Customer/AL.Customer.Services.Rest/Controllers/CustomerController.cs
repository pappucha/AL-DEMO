﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AL.Customer.Domain.Interface;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace AL.Customer.Services.Rest.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomerController : Controller
    {
        /// <summary>
        /// Tieup service.
        /// </summary>
        private readonly ICustomerService customerService;

        public CustomerController(ICustomerService _customerService)
        {
            this.customerService = _customerService;
        }

        // GET: /<controller>/
        public IActionResult Index()
        {
            return View();
        }

        /// <summary>
        /// Get list of customers without Order.
        /// </summary>
        /// <returns>Return list of customers without Order.</returns>
        [HttpGet]
        [ProducesResponseType(typeof(List<string>), StatusCodes.Status200OK)]
        public async Task<IActionResult> CustomerNoOrder()
        {

            var getCustomerWithNoOrder =  this.customerService.CustomerNoOrder();
            if (getCustomerWithNoOrder != null)
            {
                return this.Ok(getCustomerWithNoOrder);
            }
            return this.NotFound();

        }

        /// <summary>
        /// Get list of customers Based on CustomerID.
        /// </summary>
        /// <returns>Return list of customers with Order.</returns>
        [HttpGet("{customerID}")]
        [ProducesResponseType(typeof(List<string>), StatusCodes.Status200OK)]
        public async Task<IActionResult> CustomeOrderDetailsByID(int customerID)
        {
            var customerOrderDetailsbyID = this.customerService.CustomeOrderDetailsByID(customerID);
            if (customerOrderDetailsbyID != null)
            {
                return this.Ok(customerOrderDetailsbyID);
            }
            return this.NotFound();
        }

        /// <summary>
        /// SaveCustomer.
        /// </summary>
        /// <returns>Return Customer.</returns>
        [HttpPost]
        [ProducesResponseType(typeof(Effigy.Models.CustomerModel), StatusCodes.Status200OK)]
        public async Task<IActionResult> SaveCustomer(Effigy.Models.CustomerModel customerModel)
        {
            if (customerModel != null)
            {
                var saveCustomer = await this.customerService.SaveCustomer(customerModel).ConfigureAwait(false);
                return saveCustomer != null ? this.Ok(saveCustomer) : (IActionResult)this.NotFound();
            }

            return this.NotFound();
        }

        /// <summary>
        /// SaveCustomer.
        /// </summary>
        /// <returns>Return Customer.</returns>
        [HttpPost("AddOrderForCustomer")]
        [ProducesResponseType(typeof(Effigy.Models.CustomerModel), StatusCodes.Status200OK)]
        public async Task<IActionResult> AddOrderForCustomer(Effigy.Models.CustomerModel customerModel)
        {
            if (customerModel != null)
            {
                var saveCustomer = await this.customerService.AddOrderForCustomer(customerModel).ConfigureAwait(false);
                return saveCustomer != null ? this.Ok(saveCustomer) : (IActionResult)this.NotFound();
            }

            return this.NotFound();
        }
    }
}
