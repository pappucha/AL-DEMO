﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AL.Customer.Data.DataAccess;
using AL.Customer.Domain.Interface;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace AL.Customer.Services.Rest.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TestController : Controller
    {
        /// <summary>
        /// Tieup service.
        /// </summary>
        private readonly ICustomerService customerService;

        public TestController(ICustomerService _customerService)
        {
            this.customerService = _customerService;
        }

        // GET: /<controller>/
        public IActionResult Index()
        {
            return View();
        }

        /// <summary>
        /// Get tieup details.
        /// </summary>
        /// <returns>Return RegularTieupModel.</returns>
        [HttpGet("GetReversalTieup")]
        [ProducesResponseType(typeof(List<string>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetReversalTieup()
        {
            var test = this.customerService.GetUserDetailsByIdentifier(1);
            return this.Ok(test);
        }
    }
}
